export interface ParsedToken {
  exp: number
  userId: string
}
