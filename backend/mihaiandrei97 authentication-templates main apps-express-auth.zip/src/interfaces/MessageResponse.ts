export default interface MessageResponse {
  message: string
}
