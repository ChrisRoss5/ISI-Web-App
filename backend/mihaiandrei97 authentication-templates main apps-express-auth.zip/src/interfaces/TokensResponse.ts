export interface TokensResponseInterface {
  access_token: string
  refresh_token?: string
}
